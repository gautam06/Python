def Isdn():
	print "I'm ISDN Phone"
