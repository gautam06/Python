def G3():
	print "I'm 3G Phone"
